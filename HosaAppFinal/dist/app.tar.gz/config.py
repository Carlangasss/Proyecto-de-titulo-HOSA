# config.py
import flet as ft

def create_config_view(page,navigate_to):
    page.clean()
    page.add(ft.Text("Bienvenido a config"))
    

     
